package org.springframework.data.jpa.domain;

import jakarta.annotation.Generated;
import jakarta.persistence.metamodel.MappedSuperclassType;
import jakarta.persistence.metamodel.SingularAttribute;
import jakarta.persistence.metamodel.StaticMetamodel;
import java.io.Serializable;

/**
 * Static metamodel for {@link org.springframework.data.jpa.domain.AbstractPersistable}
 **/
@StaticMetamodel(AbstractPersistable.class)
@Generated("org.hibernate.processor.HibernateProcessor")
public abstract class AbstractPersistable_ {

	
	/**
	 * @see #id
	 **/
	public static final String ID = "id";

	
	/**
	 * Static metamodel type for {@link org.springframework.data.jpa.domain.AbstractPersistable}
	 **/
	public static volatile MappedSuperclassType<AbstractPersistable> class_;
	
	/**
	 * Static metamodel for attribute {@link org.springframework.data.jpa.domain.AbstractPersistable#id}
	 **/
	public static volatile SingularAttribute<AbstractPersistable, Serializable> id;

}

