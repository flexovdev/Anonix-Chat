package org.springframework.data.jpa.domain;

import jakarta.annotation.Generated;
import jakarta.persistence.metamodel.MappedSuperclassType;
import jakarta.persistence.metamodel.SingularAttribute;
import jakarta.persistence.metamodel.StaticMetamodel;
import java.time.Instant;

/**
 * Static metamodel for {@link org.springframework.data.jpa.domain.AbstractAuditable}
 **/
@StaticMetamodel(AbstractAuditable.class)
@Generated("org.hibernate.processor.HibernateProcessor")
public abstract class AbstractAuditable_ extends AbstractPersistable_ {

	
	/**
	 * @see #createdBy
	 **/
	public static final String CREATED_BY = "createdBy";
	
	/**
	 * @see #createdDate
	 **/
	public static final String CREATED_DATE = "createdDate";
	
	/**
	 * @see #lastModifiedBy
	 **/
	public static final String LAST_MODIFIED_BY = "lastModifiedBy";
	
	/**
	 * @see #lastModifiedDate
	 **/
	public static final String LAST_MODIFIED_DATE = "lastModifiedDate";

	
	/**
	 * Static metamodel type for {@link org.springframework.data.jpa.domain.AbstractAuditable}
	 **/
	public static volatile MappedSuperclassType<AbstractAuditable> class_;
	
	/**
	 * Static metamodel for attribute {@link org.springframework.data.jpa.domain.AbstractAuditable#createdBy}
	 **/
	public static volatile SingularAttribute<AbstractAuditable, Object> createdBy;
	
	/**
	 * Static metamodel for attribute {@link org.springframework.data.jpa.domain.AbstractAuditable#createdDate}
	 **/
	public static volatile SingularAttribute<AbstractAuditable, Instant> createdDate;
	
	/**
	 * Static metamodel for attribute {@link org.springframework.data.jpa.domain.AbstractAuditable#lastModifiedBy}
	 **/
	public static volatile SingularAttribute<AbstractAuditable, Object> lastModifiedBy;
	
	/**
	 * Static metamodel for attribute {@link org.springframework.data.jpa.domain.AbstractAuditable#lastModifiedDate}
	 **/
	public static volatile SingularAttribute<AbstractAuditable, Instant> lastModifiedDate;

}

